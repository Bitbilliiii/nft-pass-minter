# TON NFT Pass Minter (Testnet) - Ready repo

## Quick steps (Codespaces)

1. Create a new GitHub repo (or use this one) and open it in Codespaces.
2. Upload this project into the repo (or clone the ZIP and open in Codespaces).

## Edit values
- Open `scripts/deploy.ts` and set `METADATA_URL` to your Pinata metadata CID, e.g. "ipfs://QmYourMetadataCID".
- Optionally set `PAYOUT` to your testnet wallet address (default is deployer wallet).
- In `web/index.html`, after deploy paste the printed contract address into `COLLECTION_ADDRESS` and set `TONCONNECT_MANIFEST_URL` to your GitHub Pages manifest URL.

## Install and compile
In Codespaces terminal:
```bash
npm i -g @tact-lang/compiler
npm i
npm run compile
```

## Deploy to testnet
- Fund a testnet wallet with faucet `@testgiver_ton_bot` on Telegram.
```bash
npm run deploy:testnet
```
Approve the deploy transaction in your wallet; the terminal will print the deployed contract address.

## Frontend
- Paste the contract address into `web/index.html` (COLLECTION_ADDRESS).
- Commit & push and enable GitHub Pages to host `web/` (Settings → Pages → branch main, folder / root).

## Notes
- Replace any placeholder strings like `REPLACE_WITH_YOUR_METADATA_CID` and `YOUR_USERNAME`.
- This repo is testnet-focused: use `--network testnet` when deploying.
