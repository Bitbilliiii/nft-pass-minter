import { NetworkProvider } from "@ton/blueprint";
import { toNano } from "@ton/core";
// This import points to the compiled Tact artifact which will be generated after compile
import { NftPassCollection } from "../build/NftPassCollection/tact_NftPassCollection";

export async function run(provider: NetworkProvider) {
  const sender = provider.sender();
  const owner = sender.address!;

  // >>> EDIT: set the wallet that should receive the 1 TON per mint (testnet)
  const PAYOUT = owner; // or replace with "EQ..." testnet address string

  // 1 TON price (in nanoTON)
  const MINT_PRICE = 1_000_000_000n;

  // total supply for your pass
  const TOTAL_SUPPLY = 10000n;

  // >>> EDIT: put your Pinata/Arweave metadata.json link here
  // Example: "ipfs://QmYourMetadataCID"
  const METADATA_URL = "ipfs://REPLACE_WITH_YOUR_METADATA_CID";

  const collection = provider.open(
    await NftPassCollection.fromInit(owner, PAYOUT, MINT_PRICE, TOTAL_SUPPLY, METADATA_URL)
  );

  // deploy with some funds for storage/gas
  await collection.sendDeploy(sender, { value: toNano("0.1") });

  console.log("✅ NftPassCollection deployed at (testnet):", collection.address.toString());
}
